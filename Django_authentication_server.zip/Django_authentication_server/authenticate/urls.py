from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('delete/', views.del_category, name="deletecat"),
    path('login/', views.login_user, name='login'),
    #path('show/', views.showuser, name="showuser"),
    path('logout/', views.logout_user, name='logout'),
    path('register/', views.register_user, name='register'),
    path('change_password', views.change_password, name='change_password'),

]
